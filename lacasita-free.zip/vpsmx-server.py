#!/usr/bin/env python3
"""
Servidor HTTP local para o esquema de key do LaCasitaMX.

Sobe em http://127.0.0.1:4444/ (porta padrao) e serve o conteudo de
vpsmx.txt em qualquer caminho (inclusive rotas tipo /.../lista-arq/...).
Isso mantem o wget do fluxo de atualizacao e o curl do function_verify
apontando para localhost.

Uso:
    python3 vpsmx-server.py [PORTA]

Exemplos:
    python3 vpsmx-server.py          # porta padrao 4444
    python3 vpsmx-server.py 5555     # porta customizada
"""

import os
import sys
import errno
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TXT_PATH = os.path.join(BASE_DIR, "vpsmx.txt")
HOST = "127.0.0.1"
DEFAULT_PORT = 4444


class LocalKeyServer(BaseHTTPRequestHandler):
    server_version = "vpsmx-local/1.0"
    allow_reuse_address = True

    def do_GET(self):
        try:
            with open(TXT_PATH, "rb") as fh:
                body = fh.read()
        except FileNotFoundError:
            body = b"127.0.0.1\n"
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        sys.stdout.write("%s - %s\n" % (self.address_string(), fmt % args))
        sys.stdout.flush()


class RestartableHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def port_in_use_hint(port):
    """
    Tenta descobrir quem esta segurando a porta, para dar uma
    mensagem util em vez de traceback crua.
    """
    import subprocess

    try:
        out = subprocess.run(
            ["ss", "-ltnp"],
            capture_output=True,
            text=True,
            timeout=5,
        ).stdout
        lines = [ln for ln in out.splitlines() if ln.find(":%d " % port) != -1 or ln.endswith(":%d" % port)]
        if lines:
            return "\n".join(lines)
    except Exception:
        pass
    return None


def main():
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            print("ERRO: a porta precisa ser um numero. Uso: python3 vpsmx-server.py [PORTA]")
            sys.exit(2)
    else:
        port = DEFAULT_PORT

    if not 0 < port < 65536:
        print("ERRO: porta fora da faixa 1-65535: %s" % port)
        sys.exit(2)

    os.chdir(BASE_DIR)
    try:
        httpd = RestartableHTTPServer((HOST, port), LocalKeyServer)
    except OSError as e:
        if e.errno == errno.EADDRINUSE:
            print("ERRO: a porta %d em %s ja esta em uso." % (port, HOST))
            hint = port_in_use_hint(port)
            if hint:
                print(hint)
            print("Dica: mate o processo dono (kill <PID>) ou use outra porta:")
            print("      python3 vpsmx-server.py %d" % (port + 1 if port < 65534 else 1))
            sys.exit(1)
        raise

    print("Servindo arquivo em http://%s:%d/vpsmx.txt (Ctrl+C para parar)" % (HOST, port))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
